package data.structure;

import java.util.*;

public class ListUtil{

    public static ArrayList<Integer> divisors(int number){

    }

    public static ArrayList<String> withSameStartEnd(ArrayList<String> txts){

    }

    public static void maxToFront(ArrayList<String> txts){
        
    }

}